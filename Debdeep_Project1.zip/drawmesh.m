function drawmesh(N)
[pos, A] = coord(N);
gplot(A, pos)